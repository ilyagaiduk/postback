-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Окт 07 2020 г., 15:25
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `gaydukwv_post`
--

-- --------------------------------------------------------

--
-- Структура таблицы `allpostback`
--
-- Создание: Окт 07 2020 г., 08:27
--

DROP TABLE IF EXISTS `allpostback`;
CREATE TABLE `allpostback` (
  `id_back` int(30) NOT NULL,
  `ID` int(100) NOT NULL,
  `Clicks` int(10) NOT NULL,
  `Installs` int(10) NOT NULL,
  `CRi` float NOT NULL,
  `Trials` int(10) NOT NULL,
  `CRti` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sumback`
--
-- Создание: Окт 07 2020 г., 10:36
-- Последнее обновление: Окт 07 2020 г., 12:22
--

DROP TABLE IF EXISTS `sumback`;
CREATE TABLE `sumback` (
  `id` int(10) NOT NULL,
  `campaign_id` int(10) NOT NULL,
  `cid` varchar(200) NOT NULL,
  `clicks` int(10) NOT NULL,
  `installs` int(10) NOT NULL,
  `trials` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sumback`
--

INSERT INTO `sumback` (`id`, `campaign_id`, `cid`, `clicks`, `installs`, `trials`) VALUES
(6, 212, '2220974dsye2sy0256', 69, 24, 24),
(7, 212, '0974dsye2sy0256', 69, 24, 24),
(8, 211, '4440974dsye2sy0256', 65, 22, 22),
(9, 211, '0984dsye2sy0256', 65, 22, 22);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `allpostback`
--
ALTER TABLE `allpostback`
  ADD PRIMARY KEY (`id_back`);

--
-- Индексы таблицы `sumback`
--
ALTER TABLE `sumback`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `allpostback`
--
ALTER TABLE `allpostback`
  MODIFY `id_back` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `sumback`
--
ALTER TABLE `sumback`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
